
package buildingclimate;



public class Main {
    
    
    
    public static void main(String[] args) {
        
        
        BuildingClimate building1 = new BuildingClimate("Bygning1", "12122","Campusvej 1");
        BuildingClimate building2 = new BuildingClimate("Bygning2", "12123","Campusvej 2");
        BuildingClimate building3 = new BuildingClimate("Bygning3", "12124","Campusvej 3");
        BuildingClimate building4 = new BuildingClimate("Bygning4", "12125","Campusvej 4");
        
        System.out.println(building1);
        
        
    }
}
