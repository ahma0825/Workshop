
package buildingclimate;

import java.util.UUID;



public class Actuator {
    
    UUID actuatorID;
    private double temperature;
    private double airQuality;
    
    
    

    public double getTemperature() {
        return temperature;
    }

    public double getAirQuality() {
        return airQuality;
    }

    public void thermostat(double temperature) {
        this.temperature = temperature;
    }

    public void changeAirQuality(double airQuality) {
        this.airQuality = airQuality;
    }
    
    
    
    
}
