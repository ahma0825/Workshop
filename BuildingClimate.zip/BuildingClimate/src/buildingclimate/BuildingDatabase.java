
package buildingclimate;

import java.util.ArrayList;


public class BuildingDatabase {
    
    ArrayList <BuildingClimate> buildingList = new ArrayList<>();
    
    
    public boolean addBuilding(BuildingClimate building){
        
        return buildingList.add(building);
        
        
    }
    
    
public ArrayList <BuildingClimate> printBuildingList(){
    
 return this.buildingList;
   
}


    
}
