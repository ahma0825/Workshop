package buildingclimate;


import java.util.ArrayList;


public class BuildingClimate {


        String UUID;
        String name;
        String location;
        
        ArrayList <Sensor> sensorList  = new ArrayList<>();
        ArrayList <Actuator> actuatorList  = new ArrayList<>(); 
        
        
        
        BuildingClimate(String name, String UUID, String location){
            
            this.name = name;
            this.UUID = UUID;
            this.location = location;
            
  
    }

    public String getUUID() {
        return UUID;
    }

    public String getName() {
        return name;
    }

    public String getLocation() {
        return location;
    }
      
    @Override
    public String toString(){
        
        return name + ", " + UUID + ", " + location  + ".";
         
    }
}
