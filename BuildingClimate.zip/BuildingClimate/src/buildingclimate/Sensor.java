
package buildingclimate;

import java.util.UUID;


public class Sensor {
    
    UUID sensorID;
    private double temperatureMeasure;
    private double airMeasure;
    
    
    
    

    public double getTemperatureValue() {
        return temperatureMeasure;
    }

    public double getAirValue() {
        return airMeasure;
    }

    public void setTemperatureValue(double temperatureMeasure) {
        this.temperatureMeasure = temperatureMeasure;
    }

    public void setAirValue(double airMeasure) {
        this.airMeasure = airMeasure;
    }
    
    
    
    
    
    
}
